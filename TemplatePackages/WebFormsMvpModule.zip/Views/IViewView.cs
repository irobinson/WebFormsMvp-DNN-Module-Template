﻿namespace $Namespace$$safeprojectname$.Views
{
    using DotNetNuke.Web.Mvp;

    public interface IViewView : IModuleView<Models.ViewModel>
    {
    }
}
