namespace $Namespace$$safeprojectname$.Models
{
    public class SettingsModel
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}