﻿namespace $Namespace$$safeprojectname$.Models
{
    public class EditModel
    {
        // add properties as appropriate
        // any data the view will need should be placed here
        public bool Success;
        public string Message;
    }
}