﻿namespace $Namespace$$safeprojectname$.Models
{
    public class ViewModel
    {
        // add properties as appropriate
        // any data the view will need should be placed here
    }
}