﻿namespace $Namespace$$safeprojectname$
{
    using MbUnit.Framework;

    [TestFixture]
    public class EditPresenterTests
    {
        [Test]
// ReSharper disable InconsistentNaming
        public void MethodUnderTest_StateUnderTest_ExpectedBehavior()
// ReSharper restore InconsistentNaming
        {
            //arrange

            //act

            //assert
        }
    }
}